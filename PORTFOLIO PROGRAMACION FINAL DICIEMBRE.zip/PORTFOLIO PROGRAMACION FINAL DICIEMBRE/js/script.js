document.addEventListener('DOMContentLoaded', function () {
    console.log('script.js loaded');

    const hamburger = document.querySelector('.hamburger');
    const menu = document.querySelector('.menu');

    if (hamburger && menu) {
        function toggleMenu() {
            const expanded = hamburger.getAttribute('aria-expanded') === 'true';
            hamburger.setAttribute('aria-expanded', String(!expanded));
            hamburger.classList.toggle('is-active');
            menu.classList.toggle('menu-open');
        }

        hamburger.addEventListener('click', toggleMenu);

        hamburger.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleMenu();
            }
        });

        document.querySelectorAll('.menu a').forEach(function (link) {
            link.addEventListener('click', function () {
                menu.classList.remove('menu-open');
                hamburger.classList.remove('is-active');
                hamburger.setAttribute('aria-expanded', 'false');
            });
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                menu.classList.remove('menu-open');
                hamburger.classList.remove('is-active');
                hamburger.setAttribute('aria-expanded', 'false');
            }
        });

        document.addEventListener('click', function (e) {
            const target = e.target;
            if (!menu.contains(target) && !hamburger.contains(target)) {
                menu.classList.remove('menu-open');
                hamburger.classList.remove('is-active');
                hamburger.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const form = document.getElementById('contactForm');
    if (form) {
        form.noValidate = true;
        const submitBtn = document.getElementById('enviarBtn');

        function updateSubmitState() {
            if (!submitBtn) return;
            submitBtn.disabled = false; 
        }

        form.querySelectorAll('input, textarea, select').forEach(function (el) {
            el.addEventListener('input', updateSubmitState);
            el.addEventListener('change', updateSubmitState);
            el.addEventListener('blur', updateSubmitState);
            el.addEventListener('keyup', updateSubmitState);
        });

        updateSubmitState();

        form.addEventListener('invalid', function (e) {
            e.preventDefault(); 
            clearAllFieldErrors();
            performValidation();
            const firstInvalid = form.querySelector('.invalid');
            if (firstInvalid) {
                try { firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (err) {}
                firstInvalid.focus();
            }
        }, true);

        form.addEventListener('submit', function (event) {
            event.preventDefault();
            clearAllFieldErrors();
            const valid = performValidation();
            if (!valid) {
                const firstInvalid = form.querySelector('.invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }

            try {
                alert('Solicitud enviada correctamente. En breve me pondré en contacto contitgo ;)');
            } catch (e) {
                showToast('Solicitud enviada correctamente', 'success', 'top');
            }
            form.reset();
        });

        function showFieldErrorById(id, msg){ const node = document.getElementById(id); if(node) node.textContent = msg; }
        function clearFieldErrorById(id){ const node = document.getElementById(id); if(node) node.textContent = ''; }
        function clearAllFieldErrors(){ ['err-nombre','err-email','err-comision'].forEach(clearFieldErrorById); form.querySelectorAll('.invalid').forEach(function(el){ el.classList.remove('invalid'); el.removeAttribute('aria-invalid'); }); }
        function performValidation(){
            let ok = true;
            const name = form.querySelector('#nombre');
            const email = form.querySelector('#email');
            const sel = form.querySelector('#comision');
            if(!name || !email || !sel) return false;
            [name, email, sel].forEach(function(el){ el.classList.remove('invalid'); el.removeAttribute('aria-invalid'); });
            clearAllFieldErrors();
            if(!name.value.trim()){ name.classList.add('invalid'); name.setAttribute('aria-invalid','true'); showFieldErrorById('err-nombre','Por favor completa tu nombre'); ok=false; }
            if(!email.value.trim()){ email.classList.add('invalid'); email.setAttribute('aria-invalid','true'); showFieldErrorById('err-email','Por favor ingresa tu correo'); ok=false; }
            else if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value.trim())){ email.classList.add('invalid'); email.setAttribute('aria-invalid','true'); showFieldErrorById('err-email','Introduce un correo válido'); ok=false; }
            if(!sel.value){ sel.classList.add('invalid'); sel.setAttribute('aria-invalid','true'); showFieldErrorById('err-comision','Selecciona una opción'); ok=false; }
            return ok;
        }
        function showToast(msg, type, position){
            const t = document.createElement('div'); t.className = 'toast ' + (type||'success') + (position==='top' ? ' top' : '');
            t.setAttribute('role','status'); t.setAttribute('aria-live','polite');
            const txt = document.createElement('div'); txt.textContent = msg; t.appendChild(txt);
            document.body.appendChild(t);
            requestAnimationFrame(()=> t.classList.add('show'));
            setTimeout(()=>{ t.classList.remove('show'); setTimeout(()=> t.remove(), 300); }, 3800);
        }
    }

    const images = [
        '../Imagenes/Siren ATC.jpeg',
        '../Imagenes/dyonisus ATC.jpeg',
        '../Imagenes/Kemane the woods guardian.jpeg',
        '../Imagenes/short hair Alex.jpeg',
        '../Imagenes/Jet and Alex chibis.jpeg',
        '../Imagenes/Garden Fairy Design.jpeg',
        '../Imagenes/Medusa the before.jpeg'
    ];
    const descriptions = [
        'Siren ATC - Año 2024',
        'Dyonisus ATC - Año 2024',
        'Kemane the woods guardian - Año 2024',
        'Short hair Alex - Año 2023',
        'Jet and Alex chibis - Año 2023',
        'Garden Fairy Design - Año 2025',
        'Medusa the before - Año 2025'
    ];
    let current = 0;
    const carouselImage = document.getElementById('carouselImage');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const carouselDesc = document.getElementById('carouselDesc');

    function showImage(index, direction) {
        if (!carouselImage) return;
        carouselImage.classList.remove('slide-left', 'slide-right');
        void carouselImage.offsetWidth;
        carouselImage.classList.add(direction === 'left' ? 'slide-left' : 'slide-right');
        setTimeout(() => {
            carouselImage.src = images[index];
            carouselImage.classList.remove('slide-left', 'slide-right');
            if (carouselDesc) {
                carouselDesc.textContent = descriptions[index];
            }
        }, 500);
    }

    if (carouselImage && prevBtn && nextBtn) {
        prevBtn.addEventListener('click', function () {
            const prev = (current - 1 + images.length) % images.length;
            showImage(prev, 'left');
            current = prev;
        });
        nextBtn.addEventListener('click', function () {
            const next = (current + 1) % images.length;
            showImage(next, 'right');
            current = next;
        });
        if (carouselDesc) carouselDesc.textContent = descriptions[current];
    }

    const starBtn = document.getElementById('starBtn');
    const starState = document.getElementById('starState'); 
    if (starBtn) {
        function setStarPlaying(v) {
            if (v) {
                starBtn.classList.add('playing');
                starBtn.setAttribute('aria-pressed', 'true');
                if (starState) starState.textContent = 'Reproduciendo';
            } else {
                starBtn.classList.remove('playing');
                starBtn.setAttribute('aria-pressed', 'false');
                if (starState) starState.textContent = 'Detenido';
            }
        }
        starBtn.addEventListener('click', function () { setStarPlaying(!starBtn.classList.contains('playing')); });
        starBtn.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') { e.preventDefault(); starBtn.click(); } });
        document.addEventListener('visibilitychange', function () { if (document.hidden) setStarPlaying(false); });
    }
});